package com.example.svakatha;

public class ChoiceModel {
    String choice;

    public String getChoice() {
        return choice;
    }

    public void setChoice(String choice) {
        this.choice = choice;
    }
}
